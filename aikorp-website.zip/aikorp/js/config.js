// ============================================================
//  EDIT YOUR SITE SETTINGS HERE
// ============================================================
const SITE = {
  name: "AI Korp",
  email: "hello@aikorp.in",
  linkedin: "#",
  github: "#",

  // Collects name + email before each download.
  // Free option: create an access key at https://web3forms.com (sent to your inbox)
  // and paste it below. Leave empty to skip collecting and just download.
  web3formsKey: "",

  // "Buy me a coffee" / UPI support link. Leave empty to hide the button.
  supportLink: "",
};

// status: "available" shows a Download button, "soon" shows "Notify me".
// file: a path in /downloads or a full URL (e.g. a GitHub release).
const TOOLS = [
  {
    id: "laptopdoctor",
    name: "LaptopDoctor",
    summary: "Checks a Windows laptop's health and fixes common problems in one click.",
    needs: "Windows 10 / 11",
    status: "available",
    file: "downloads/LaptopDoctor.zip",
  },
  {
    id: "inactive-users",
    name: "M365 Inactive User Report",
    summary: "Finds users who haven't signed in for 90+ days and the licences they still hold.",
    needs: "PowerShell 7 · Microsoft.Graph",
    status: "available",
    file: "downloads/M365-InactiveUserReport.zip",
  },
  {
    id: "onboarding",
    name: "M365 Onboarding & Offboarding Kit",
    summary: "Creates or retires a user with licences, groups, mailbox and Teams in one run.",
    needs: "PowerShell 7 · Microsoft.Graph · ExchangeOnline",
    status: "soon",
    file: "",
  },
  {
    id: "ad-cleanup",
    name: "AD Stale Object Cleanup",
    summary: "Reports stale computers, disabled users, empty groups and non-expiring passwords.",
    needs: "Windows PowerShell 5.1 · RSAT ActiveDirectory",
    status: "soon",
    file: "",
  },
  {
    id: "tenant-check",
    name: "M365 Tenant Security Check",
    summary: "Shows MFA status, admin role holders and mailboxes forwarding mail outside.",
    needs: "PowerShell 7 · Microsoft.Graph · ExchangeOnline",
    status: "soon",
    file: "",
  },
];
