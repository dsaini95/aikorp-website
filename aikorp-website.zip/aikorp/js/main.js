(() => {
  const $ = (s) => document.querySelector(s);
  const $$ = (s) => [...document.querySelectorAll(s)];
  const toolById = Object.fromEntries(TOOLS.map((t) => [t.id, t]));
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

  // ---------- Site details ----------
  $("#year").textContent = new Date().getFullYear();
  $$("[data-mail]").forEach((a) => (a.href = "mailto:" + SITE.email));
  $$("[data-linkedin]").forEach((a) => (a.href = SITE.linkedin));
  $$("[data-github]").forEach((a) => (a.href = SITE.github));
  if (SITE.supportLink) { $("#support").hidden = false; $("#supportLink").href = SITE.supportLink; }

  // ---------- Mobile menu ----------
  const menu = $("#menu"), nav = $("#nav");
  menu.onclick = () => { const open = nav.classList.toggle("open"); menu.setAttribute("aria-expanded", open); };
  $$("#nav a").forEach((a) => a.addEventListener("click", () => { nav.classList.remove("open"); menu.setAttribute("aria-expanded", false); }));

  // ---------- Catalogue ----------
  $("#catalog").innerHTML = TOOLS.map((t) => `
    <div class="catalog-row" role="row">
      <div role="cell">
        <div class="tool-name">${esc(t.name)} ${t.status === "available" ? '<span class="tag">Free</span>' : '<span class="tag soon">Coming soon</span>'}</div>
        <p class="tool-sum">${esc(t.summary)}</p>
      </div>
      <div class="tool-needs" role="cell">${esc(t.needs)}</div>
      <div role="cell">
        ${t.status === "available"
          ? `<button class="btn btn-solid" data-download="${t.id}">Download</button>`
          : `<button class="btn btn-ghost" data-download="${t.id}">Notify me</button>`}
      </div>
    </div>`).join("");

  // ---------- Download / notify dialog ----------
  const dlg = $("#dlg");
  let current = null;
  document.addEventListener("click", (e) => {
    const b = e.target.closest("[data-download]");
    if (!b) return;
    current = toolById[b.dataset.download];
    const soon = current.status !== "available";
    $("#dlgTitle").textContent = soon ? `Get notified about ${current.name}` : `Download ${current.name}`;
    $("#dlgSummary").textContent = soon ? "Leave your email and I'll send you the download the day it's released." : current.summary;
    $("#leadBtn").textContent = soon ? "Notify me" : "Get the download";
    $("#leadForm .check").hidden = soon;
    $("#dlgForm").hidden = false; $("#dlgDone").hidden = true; $("#leadErr").hidden = true;
    dlg.showModal();
  });
  dlg.addEventListener("click", (e) => { if (e.target === dlg) dlg.close(); });

  async function sendLead(fields) {
    if (!SITE.web3formsKey) return true;
    const res = await fetch("https://api.web3forms.com/submit", {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify({ access_key: SITE.web3formsKey, subject: `AI Korp: ${fields.type}`, from_name: "aikorp.in", ...fields }),
    });
    return res.ok;
  }

  $("#leadForm").onsubmit = async (e) => {
    e.preventDefault();
    const f = Object.fromEntries(new FormData(e.target));
    const soon = current.status !== "available";
    const btn = $("#leadBtn"); const label = btn.textContent;
    btn.disabled = true; btn.textContent = "Sending…";
    try {
      const ok = await sendLead({ type: soon ? "notify" : "download", tool: current.name, name: f.name, email: f.email, updates: f.updates ? "yes" : "no" });
      if (!ok) throw new Error();
    } catch {
      if (soon) { $("#leadErr").textContent = "Couldn't save your email. Check your connection and try again."; $("#leadErr").hidden = false; btn.disabled = false; btn.textContent = label; return; }
    }
    btn.disabled = false; btn.textContent = label;
    $("#dlgForm").hidden = true; $("#dlgDone").hidden = false;
    if (soon) {
      $("#doneTitle").textContent = "You're on the list";
      $("#doneText").textContent = `I'll email ${f.email} when ${current.name} is released.`;
      $("#doneLink").hidden = true;
    } else {
      $("#doneTitle").textContent = "Your download is ready";
      $("#doneText").textContent = `Thanks, ${f.name.split(" ")[0]}. If it doesn't start, use the button below.`;
      const link = $("#doneLink"); link.hidden = false; link.href = current.file;
      link.click();
    }
    e.target.reset();
  };

  // ---------- Newsletter ----------
  $("#signupForm").onsubmit = async (e) => {
    e.preventDefault();
    const email = new FormData(e.target).get("email");
    try { await sendLead({ type: "newsletter", email }); toast("Subscribed. Watch your inbox for the next tool."); e.target.reset(); }
    catch { toast("Couldn't subscribe. Check your connection and try again."); }
  };

  let tt;
  function toast(text) { const el = $("#toast"); el.textContent = text; el.classList.add("show"); clearTimeout(tt); tt = setTimeout(() => el.classList.remove("show"), 2800); }

  // ---------- Hero console ----------
  const out = $("#console");
  const script = [
    { t: "Windows PowerShell\nCopyright (C) Microsoft Corporation. All rights reserved.\n\n", c: "p" },
    { t: "PS C:\\Tools> ", c: "p" },
    { t: "Connect-MgGraph", c: "cmd", type: true }, { t: " -Scopes ", c: "par", type: true }, { t: "\"User.Read.All\",\"AuditLog.Read.All\"\n", c: "str", type: true },
    { t: "Welcome to Microsoft Graph!\n\n", c: "dim", wait: 500 },
    { t: "PS C:\\Tools> ", c: "p" },
    { t: ".\\Get-InactiveUsers.ps1", c: "cmd", type: true }, { t: " -Days ", c: "par", type: true }, { t: "90", c: "p", type: true }, { t: " -IncludeLicenses\n", c: "par", type: true },
    { t: "Scanning 1,248 users ", c: "dim", wait: 300 }, { t: "...........", c: "dim", slow: true }, { t: " done\n\n", c: "ok" },
    { t: "DisplayName        LastSignIn   Days  Licence\n", c: "p", wait: 200 },
    { t: "-----------        ----------   ----  -------\n", c: "p" },
    { t: "Priya Nair         2026-06-02    166  M365 E3\n", c: "p", wait: 120 },
    { t: "Rahul Verma        2026-07-19    119  M365 Business Premium\n", c: "p", wait: 120 },
    { t: "Test.Account01     Never           -  M365 E3\n", c: "warn", wait: 120 },
    { t: "Anil Kapoor        2026-08-10     97  Exchange Online P1\n\n", c: "p", wait: 120 },
    { t: "WARNING: 37 inactive users hold 41 paid licences.\n", c: "warn", wait: 300 },
    { t: "Report saved to C:\\Tools\\InactiveUsers.csv\n\n", c: "ok", wait: 200 },
    { t: "PS C:\\Tools> ", c: "p" },
  ];
  const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const cursor = document.createElement("span"); cursor.className = "cursor";

  async function play() {
    out.innerHTML = ""; out.appendChild(cursor);
    for (const seg of script) {
      const span = document.createElement("span"); span.className = seg.c;
      out.insertBefore(span, cursor);
      if (seg.wait && !reduce) await sleep(seg.wait);
      if (reduce || (!seg.type && !seg.slow)) { span.textContent = seg.t; out.scrollTop = out.scrollHeight; continue; }
      for (const ch of seg.t) { span.textContent += ch; out.scrollTop = out.scrollHeight; await sleep(seg.slow ? 110 : 28 + Math.random() * 40); }
    }
  }
  play();
})();
